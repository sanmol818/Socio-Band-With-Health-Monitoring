package com.example.anmolsharma.LoginActivity;
-import ...
public class LogIn extends AppCompatActivity {
	

	private Button buttonSignIn;
	private EditText editTextEmail;
	private EditText editTextPassword;
	private Progress Dialog progressDialog;
	private FirebaseAuth firebaseAuth;


@Override

protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState); 
	getContentView(R.layout.activity_log_in); 
	Toolbar toolbar = (Toolbar) findViewById(R.id. toolbar); 
	set SupportActionBar (toolbar);

	
	buttonSign In = (Button) findViewById(R.id. Log_in); 
	editTextEmail = (EditText) findViewById(R.id.email Log); 
	editTextPassword = (EditText) findViewById(R.id. password_log);
	progressDialog = new ProgressDialog (this); 
	firebaseAuth = FirebaseAuth.getInstance();
	if (firebaseAuth.getCurrentUser() !=null) {
		finish(); 
		startActivity (new Intent (getApplicationContext(), ProfileActivity.class));
	}
	
	
	public class Users_Info extends AppCompatActivity !
		private EditText inputName, inputEmail, inputcontact, dob, profession, organisation, describe; 
		private Button btnSave; 
		private Database Reference mFirebaseDatabase; 
		private FirebaseDatabase mFirebaseInstance; 
		private String userId;
	@Override 
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState); 
		set ContentView(R.layout.activity users_info);
		inputName - (EditText) findViewById(R.id.name); 
		inputEmail = (EditText) findViewById(R.id.email); 
		inputcontact - (EditText) findViewById(R.id. Contact); 
		dob = (EditText) findViewById(R.id. Date of Birth): 
		profession = (EditText) findViewById(R.id. Profession); 
		organisation = (EditText) findViewById(R.id. Name of organisation);
		describe = (EditText) findViewById(R.id. Describe_Yourself); 
		btnSave = (Button) findViewById(R.id.btn_save):
	// Firebase database 
		mPirebase Instance - FirebaseDatabase.getInstance();
	//get reference to users nodes 
		mFirebaseDatabase = mFirebaseInstance.getReference ("users):
		mFirebaseInstance = mFirebaseDatabase.getInstance();
	//get reference to users nodes 
		mFirebaseDatabase - mFirebaseInstance.getReference ("users");
	
		
	btnSave.setOnClickListener( (v) [
	    String name = inputName.getText().toString();
	    String email = inputEmail.getText().toString(); 
	    String Contact = inputcontact.getText().toString();
	    String DOB = dob.getText().toString(); 
	    String Profession = profession.getText().toString(); 
	    String Organisation = organisation.getText().toString();
	    String Describe = describe.getText().toString();
	    if (TextUtils.isEmpty(userId))
	    {	
	    	createUser (name, email, Contact , DOB, Profession, Organisation, Describe);
	    	Click_Proceed(); 
	    }	
	    	else {
	    		
	    }
	// updateUser (name, email, Contact, DOB, Profession, Organisation, Describe);
	);
	    
	  toggleButton();
	  
}
private void toggleButton()

	if (TextUtils.isEmpty(userId))
	{
		btnSave.setText("Save"); 
	}else
	{
		btnSave.setText("Update");
	}
	
private void Click_Proceed()
{
	finish(); 
	startActivity (new Intent (getApplicationContext(), ProfileActivity.class));
}

private void createUser (String Name, String Email, String Contact, String DOB, String Profession, String Organisation, String Descr:
	if (TextUtils.isEmpty(userId))
	{	
	userId = mFirebaseDatabase.push().getKey();
	}
	User user = new User (Name, Email, Contact, DOB, Profession, Organisation, Describe_yourself);
	mFirebaseDatabase.child(userId).setValue (user); // startActivity (nev Intent(getApplicationContext(), ProfileActivity.class));

