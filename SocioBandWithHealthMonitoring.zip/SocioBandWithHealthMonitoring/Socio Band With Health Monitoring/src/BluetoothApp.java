package com.example.anmolsharma.BluetoothActivity;
import ...
public class MainActivity extends AppCompatActivity!
	BluetoothSocket mmSocket;
	BluetoothSocket mmDevice;
	Button Bluetooth On, Bluetooth Off, Bluetooth list; BluetoothHeadset mBluetooth Headset; 
	BluetoothAdapter mBluetoothAdapter BluetoothAdapter.getDefaultAdapter(); 
	TextView textView; ListView lv; 
	public static String EXTRA ADDRESS = "device_address"; 
	@Override 
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState); 
		setContentView(R.layout.activity_main);
		
		Bluetooth On = (Button) findViewById(R.id.button); 
		Bluetooth Off = (Button) findViewById(R.id.button 4); 
		Bluetooth list = (Button) findViewById(R.id.button3); 
		lv = (ListView) findViewById(R.id. ListView); // textViev=(TextViev) findViewById(R.id.textViev); //new code for managing only one Bluetooth headset

		public void on (View v) {
			//for setting up the Bluetooth 
			if (mBluetoothAdapter==null)
				Toast.makeText(getApplicationContext(). "Bluetooth Device not supported", Toast. LENGTH_SHORT).show();
			if (!mBluetoothAdapter.isEnabled())
				Intent enableBtIntent=new Intent(BluetoothAdapter. ACTION REQUEST_ENABLE); 
				startActivityForRegult (enableBtIntent, 1); 
				Toast.makeText (getApplicationContext(), "Bluetooth Device Turned On", Toast. LENGTH_SHORT).show();
			//for opening a connection // finder();
		public void discoverable (View v) {
			Intent discoverableIntent=new Intent(Bluetooth Adapter. ACTION REQUEST_DISCOVERABLE);
			discoverableIntent.putExtra (BluetoothAdapter. EXTRA DISCOVERABLE DURATION, 300);
			startActivity (discoverableIntent); 
			Toast.makeText (getApplicationContext(). "Discoverable" ,Toast. LENGTH_LONG).show();
			
		public void 1ist(View v)
			SetpairedDevices = mBluetoothAdapter.getBondedDevices():
			ArrayList list - new ArrayList(); 
			if (pairedDevices.size() >0)
			{	
				for (Bluetooth Device bt : pairedDevices) list.add(bt.getName()+"\n"+bt.getAddress());
				Toast.makeText(getApplicationContext(). "Showing Paired Devices", Toast. LENGTH SHORT).show();
			else
			Toast.makeText (getApplicationContext(). "No Paired Bluetooth Devices Pound", Toast.LENGTH_SHORT).show();
			final ArrayAdapter adapter - new ArrayAdapter (this, android. R.layout.simple_list_item_1, list): lv.setAdapter (adapter): lv.setOnItemClickListener(my ListClickListener):
			{
			private AdapterView.On ItemClickListener myListClickListener(parent, view, position, id)
			String info=((TextView)view).getText().toString(); String address=info.substring(info.length() - 17);
			Intent i=new Intent (MainActivity. this, Receive_send_Data.class);//vhen changing from this class write the name of class chang 1. putExtra (EXTRA ADDRESS, address); startActivity (1):


